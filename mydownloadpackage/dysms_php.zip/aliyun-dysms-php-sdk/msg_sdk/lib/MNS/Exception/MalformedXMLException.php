<?php
namespace AliyunMNS\Exception;

use AliyunMNS\Exception\MnsException;

class MalformedXMLException extends MnsException
{
}

?>
